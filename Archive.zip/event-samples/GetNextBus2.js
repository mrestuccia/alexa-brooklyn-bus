module.exports = {
  "session": {
    "sessionId": "SessionId.448dcae4-3518-4f5b-841f-89b186a56817",
    "application": {
      "applicationId": "amzn1.ask.skill.437c7a75-b75f-4ffd-83d7-c78bbfa912c2"
    },
    "attributes": {},
    "user": {
      "userId": "amzn1.ask.account.AFMUTQH5N6AMGXTI2RNZ3MOWPAHHBZJSLMYTWRVNQQTHPIFL3XMHP4OIHWBX4AIZAEIX7SWR7R2QQJIR2XPG6V4RV5FUSFLFKQSE5XNVZU6WNJXQ4V4G2CQJY4BMDHUFKPCA2G55BUWJCL652VKJJUYUV46GPLECGUQ4MUDDII4BTGHPXK5YUEMJVBONR3N6ZF6CNTQNRW226AY"
    },
    "new": true
  },
  "request": {
    "type": "IntentRequest",
    "requestId": "EdwRequestId.1b20d5cf-c509-4715-bdf8-20a34c63472f",
    "locale": "en-US",
    "timestamp": "2017-05-12T19:52:52Z",
    "intent": {
      "name": "GetNextBus",
      "slots": {
        "bus": {
          "name": "bus",
          "value": "48"
        }
      }
    }
  },
  "version": "1.0"
};
